<?php
declare(strict_types=1);

$host = '127.0.0.1';
$port = '3307';
$dbname = 'expense_tracker';
$username = 'root';
$password = 'Marecek123!';

try {
    $pdo = new PDO(
        "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die('Chyba pripojenia k databáze: ' . $e->getMessage());
}
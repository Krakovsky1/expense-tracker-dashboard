<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Tracker</title>
    <link rel="stylesheet" href="/expense-tracker/assets/style.css">
</head>
<body>
    <header class="topbar">
        <h1>Expense Tracker555</h1>
        <nav>
            <a href="index.php">Dashboard</a>
            <a href="add_transaction.php">Pridať transakciu</a>
            <a href="transactions.php">Transakcie</a>
        </nav>
    </header>
    <main class="container">
<?php
declare(strict_types=1);

require_once '../config/db.php';

$userId = 1;

$stmt = $pdo->prepare("
    SELECT 
        t.id,
        t.amount,
        t.note,
        t.transaction_date,
        c.name AS category_name,
        c.type AS category_type
    FROM transactions t
    JOIN categories c ON t.category_id = c.id
    WHERE t.user_id = :user_id
    ORDER BY t.transaction_date DESC, t.id DESC
");
$stmt->execute(['user_id' => $userId]);
$transactions = $stmt->fetchAll();

include '../partials/header.php';
?>

<h2>Transakcie</h2>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Kategória</th>
            <th>Typ</th>
            <th>Suma</th>
            <th>Poznámka</th>
            <th>Dátum</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($transactions as $transaction): ?>
            <tr>
                <td><?= (int)$transaction['id'] ?></td>
                <td><?= htmlspecialchars($transaction['category_name']) ?></td>
                <td><?= htmlspecialchars($transaction['category_type']) ?></td>
                <td><?= number_format((float)$transaction['amount'], 2) ?> €</td>
                <td><?= htmlspecialchars($transaction['note'] ?? '') ?></td>
                <td><?= htmlspecialchars($transaction['transaction_date']) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?php include '../partials/footer.php'; ?>
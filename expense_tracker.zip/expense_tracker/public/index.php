<?php
declare(strict_types=1);

require_once '../config/db.php';

$userId = 1;
$success = '';
$error = '';
$selectedMonth = $_GET['month'] ?? date('Y-m');

$startDate = $selectedMonth . '-01';
$endDate = date('Y-m-t', strtotime($startDate));

/*
|--------------------------------------------------------------------------
| Načítanie kategórií pre formulár
|--------------------------------------------------------------------------
*/
$categoriesStmt = $pdo->prepare("
    SELECT id, name, type
    FROM categories
    WHERE user_id = :user_id
    ORDER BY type, name
");
$categoriesStmt->execute(['user_id' => $userId]);
$categories = $categoriesStmt->fetchAll();

/*
|--------------------------------------------------------------------------
| Spracovanie formulára na pridanie transakcie
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $categoryId = (int)($_POST['category_id'] ?? 0);
    $amount = (float)($_POST['amount'] ?? 0);
    $note = trim($_POST['note'] ?? '');
    $transactionDate = $_POST['transaction_date'] ?? '';

    if ($categoryId <= 0 || $amount <= 0 || $transactionDate === '') {
        $error = 'Vyplň všetky povinné polia správne.';
    } else {
        $insertStmt = $pdo->prepare("
            INSERT INTO transactions (user_id, category_id, amount, note, transaction_date)
            VALUES (:user_id, :category_id, :amount, :note, :transaction_date)
        ");

        $insertStmt->execute([
            'user_id' => $userId,
            'category_id' => $categoryId,
            'amount' => $amount,
            'note' => $note,
            'transaction_date' => $transactionDate,
        ]);

        $success = 'Transakcia bola úspešne pridaná.';

        // Refresh po uložení, aby sa neodosielal formulár znova pri refreshi
        header('Location: index.php?month=' . urlencode($selectedMonth) . '&success=1');
        exit;
    }
}

if (isset($_GET['success']) && $_GET['success'] === '1') {
    $success = 'Transakcia bola úspešne pridaná.';
}

/*
|--------------------------------------------------------------------------
| Dashboard štatistiky
|--------------------------------------------------------------------------
*/
$totalIncomeStmt = $pdo->prepare("
    SELECT COALESCE(SUM(t.amount), 0) AS total_income
    FROM transactions t
    JOIN categories c ON t.category_id = c.id
    WHERE t.user_id = :user_id
      AND c.type = 'income'
      AND t.transaction_date BETWEEN :start_date AND :end_date
");
$totalIncomeStmt->execute([
    'user_id' => $userId,
    'start_date' => $startDate,
    'end_date' => $endDate
]);
$totalIncome = (float)$totalIncomeStmt->fetch()['total_income'];

$totalExpenseStmt = $pdo->prepare("
    SELECT COALESCE(SUM(t.amount), 0) AS total_expense
    FROM transactions t
    JOIN categories c ON t.category_id = c.id
    WHERE t.user_id = :user_id
      AND c.type = 'expense'
      AND t.transaction_date BETWEEN :start_date AND :end_date
");
$totalExpenseStmt->execute([
    'user_id' => $userId,
    'start_date' => $startDate,
    'end_date' => $endDate
]);
$totalExpense = (float)$totalExpenseStmt->fetch()['total_expense'];

$balance = $totalIncome - $totalExpense;

/*
|--------------------------------------------------------------------------
| Top kategórie výdavkov
|--------------------------------------------------------------------------
*/
$topCategoriesStmt = $pdo->prepare("
    SELECT c.name, SUM(t.amount) AS total_spent
    FROM transactions t
    JOIN categories c ON t.category_id = c.id
    WHERE t.user_id = :user_id
      AND c.type = 'expense'
      AND t.transaction_date BETWEEN :start_date AND :end_date
    GROUP BY c.id, c.name
    ORDER BY total_spent DESC
    LIMIT 5
");
$topCategoriesStmt->execute([
    'user_id' => $userId,
    'start_date' => $startDate,
    'end_date' => $endDate
]);
$topCategories = $topCategoriesStmt->fetchAll();

/*
|--------------------------------------------------------------------------
| Budget alert
|--------------------------------------------------------------------------
*/
$budgetStmt = $pdo->prepare("
    SELECT 
        c.name,
        b.monthly_limit,
        COALESCE(SUM(t.amount), 0) AS spent
    FROM budgets b
    JOIN categories c ON b.category_id = c.id
    LEFT JOIN transactions t 
        ON t.category_id = b.category_id
        AND t.user_id = b.user_id
        AND t.transaction_date BETWEEN :start_date AND :end_date
    WHERE b.user_id = :user_id
      AND b.month_year = :selected_month
    GROUP BY c.id, c.name, b.monthly_limit
    ORDER BY spent DESC
");
$budgetStmt->execute([
    'user_id' => $userId,
    'start_date' => $startDate,
    'end_date' => $endDate,
    'selected_month' => $selectedMonth
]);
$budgetStatus = $budgetStmt->fetchAll();

/*
|--------------------------------------------------------------------------
| Posledných 10 transakcií
|--------------------------------------------------------------------------
*/
$transactionsStmt = $pdo->prepare("
    SELECT 
        t.amount,
        t.note,
        t.transaction_date,
        c.name AS category_name,
        c.type AS category_type
    FROM transactions t
    JOIN categories c ON t.category_id = c.id
    WHERE t.user_id = :user_id
      AND t.transaction_date BETWEEN :start_date AND :end_date
    ORDER BY t.transaction_date DESC, t.id DESC
    LIMIT 10
");
$transactionsStmt->execute([
    'user_id' => $userId,
    'start_date' => $startDate,
    'end_date' => $endDate
]);
$transactions = $transactionsStmt->fetchAll();

include '../partials/header.php';
?>

<h2>Dashboard</h2>

<div class="card">
    <h2>Pridať transakciu</h2>

    <?php if ($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <label for="category_id">Kategória</label>
        <select name="category_id" id="category_id" required>
            <option value="">-- Vyber kategóriu --</option>
            <?php foreach ($categories as $category): ?>
                <option value="<?= (int)$category['id'] ?>">
                    <?= htmlspecialchars($category['name']) ?> (<?= htmlspecialchars($category['type']) ?>)
                </option>
            <?php endforeach; ?>
        </select>

        <label for="amount">Suma</label>
        <input type="number" step="0.01" name="amount" id="amount" required>

        <label for="note">Poznámka</label>
        <input type="text" name="note" id="note" maxlength="255">

        <label for="transaction_date">Dátum</label>
        <input type="date" name="transaction_date" id="transaction_date" required>

        <button type="submit">Uložiť transakciu</button>
    </form>
</div>

<div class="card">
    <form method="GET">
        <label for="month">Vyber mesiac</label>
        <input type="month" name="month" id="month" value="<?= htmlspecialchars($selectedMonth) ?>">
        <button type="submit">Filtrovať</button>
    </form>
</div>

<div class="stats">
    <div class="stat-box">
        <h3>Celkové príjmy</h3>
        <p style="color: green;">
            <?= number_format($totalIncome, 2) ?> €
        </p>
    </div>

    <div class="stat-box">
        <h3>Celkové výdavky</h3>
        <p style="color: red;">
            <?= number_format($totalExpense, 2) ?> €
        </p>
    </div>

    <div class="stat-box">
        <h3>Zostatok</h3>
        <p style="color: <?= $balance >= 0 ? 'green' : 'red' ?>;">
            <?= number_format($balance, 2) ?> €
        </p>
    </div>
</div>

<div class="card">
    <h2>Top kategórie výdavkov</h2>

    <?php if (count($topCategories) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Kategória</th>
                    <th>Minuté</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($topCategories as $category): ?>
                    <tr>
                        <td><?= htmlspecialchars($category['name']) ?></td>
                        <td><?= number_format((float)$category['total_spent'], 2) ?> €</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div style="max-width: 280px; margin: 20px auto;">
            <canvas id="categoryChart"></canvas>
        </div>
    <?php else: ?>
        <p>Pre zvolený mesiac neexistujú žiadne výdavky.</p>
    <?php endif; ?>
</div>

<div class="card">
    <h2>Transakcie</h2>

    <?php if (count($transactions) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Kategória</th>
                    <th>Typ</th>
                    <th>Suma</th>
                    <th>Poznámka</th>
                    <th>Dátum</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($transactions as $transaction): ?>
                    <tr>
                        <td><?= htmlspecialchars($transaction['category_name']) ?></td>
                        <td><?= htmlspecialchars($transaction['category_type']) ?></td>
                        <td><?= number_format((float)$transaction['amount'], 2) ?> €</td>
                        <td><?= htmlspecialchars($transaction['note'] ?? '') ?></td>
                        <td><?= htmlspecialchars($transaction['transaction_date']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Pre zvolený mesiac nie sú žiadne transakcie.</p>
    <?php endif; ?>
</div>

<div class="card">
    <h2>Budget alert</h2>

    <?php if (count($budgetStatus) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Kategória</th>
                    <th>Limit</th>
                    <th>Minuté</th>
                    <th>Stav</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($budgetStatus as $budget): ?>
                    <?php
                        $limit = (float)$budget['monthly_limit'];
                        $spent = (float)$budget['spent'];
                        $isExceeded = $spent > $limit;
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($budget['name']) ?></td>
                        <td><?= number_format($limit, 2) ?> €</td>
                        <td><?= number_format($spent, 2) ?> €</td>
                        <td style="color: <?= $isExceeded ? 'red' : 'green' ?>;">
                            <?= $isExceeded ? 'Prekročený limit' : 'V norme' ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Pre zvolený mesiac nie sú nastavené žiadne budgety.</p>
    <?php endif; ?>
</div>

<?php if (count($topCategories) > 0): ?>
<script>
const data = {
    labels: <?= json_encode(array_column($topCategories, 'name')) ?>,
    datasets: [{
        label: 'Výdavky',
        data: <?= json_encode(array_map(fn($c) => (float)$c['total_spent'], $topCategories)) ?>,
    }]
};

new Chart(document.getElementById('categoryChart'), {
    type: 'pie',
    data: data,
    options: {
        responsive: true,
        maintainAspectRatio: true
    }
});
</script>
<?php endif; ?>

<?php include '../partials/footer.php'; ?>
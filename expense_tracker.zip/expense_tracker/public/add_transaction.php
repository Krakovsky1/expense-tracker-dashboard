<?php
declare(strict_types=1);

require_once '../config/db.php';

$userId = 1;
$success = '';
$error = '';

$categoriesStmt = $pdo->prepare("
    SELECT id, name, type
    FROM categories
    WHERE user_id = :user_id
    ORDER BY type, name
");
$categoriesStmt->execute(['user_id' => $userId]);
$categories = $categoriesStmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $categoryId = (int)($_POST['category_id'] ?? 0);
    $amount = (float)($_POST['amount'] ?? 0);
    $note = trim($_POST['note'] ?? '');
    $transactionDate = $_POST['transaction_date'] ?? '';

    if ($categoryId <= 0 || $amount <= 0 || $transactionDate === '') {
        $error = 'Vyplň všetky povinné polia správne.';
    } else {
        $insertStmt = $pdo->prepare("
            INSERT INTO transactions (user_id, category_id, amount, note, transaction_date)
            VALUES (:user_id, :category_id, :amount, :note, :transaction_date)
        ");

        $insertStmt->execute([
            'user_id' => $userId,
            'category_id' => $categoryId,
            'amount' => $amount,
            'note' => $note,
            'transaction_date' => $transactionDate,
        ]);

        $success = 'Transakcia bola úspešne pridaná.';
    }
}

include '../partials/header.php';
?>

<div class="card">
    <h2>Pridať transakciu</h2>

    <?php if ($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <label for="category_id">Kategória</label>
        <select name="category_id" id="category_id" required>
            <option value="">-- Vyber kategóriu --</option>
            <?php foreach ($categories as $category): ?>
                <option value="<?= (int)$category['id'] ?>">
                    <?= htmlspecialchars($category['name']) ?> (<?= htmlspecialchars($category['type']) ?>)
                </option>
            <?php endforeach; ?>
        </select>

        <label for="amount">Suma</label>
        <input type="number" step="0.01" name="amount" id="amount" required>

        <label for="note">Poznámka</label>
        <input type="text" name="note" id="note" maxlength="255">

        <label for="transaction_date">Dátum</label>
        <input type="date" name="transaction_date" id="transaction_date" required>

        <button type="submit">Uložiť transakciu</button>
    </form>
</div>

<?php include '../partials/footer.php'; ?>